1. For the purpose of determining origin of a good, accessories, spare parts, information material, and tools that are classified with, delivered with but not invoiced separately from a good shall be:

    (a) disregarded in determining whether a good is wholly obtained or satisfies a process or change in tariff classification requirement set out in Annex II (Product Specific Rules of Origin) for the good; and

    (b) taken into account as originating or non-originating materials, as the case may be, in calculating the regional value content of the good,

provided the quantities, value, and type of accessories, spare parts, instructional or other information materials, and tools are customary for the good.

{{ Article 12 }}
