1.	For a set classified as a result of the application of rule 3(a) or rule 3(b) of the General Rules for the Interpretation of the Harmonized System, the originating status of the set shall be determined in accordance with the product-specific rule of origin that applies to the set.

2.	For a set classified as a result of the application of rule 3(c) of the General Rules for the Interpretation of the Harmonized System, the set shall be originating only if each good in the set is originating and both the set and the goods meet the other applicable requirements of this Origin Reference Document.

3.	Notwithstanding paragraph 2, for a set classified as a result of the application of rule 3(c) of the General Rules for the Interpretation of the Harmonized System, the set is originating if the value of all the non-originating goods in the set does not exceed 20 per cent of the value of the set.

4.	For the purposes of paragraph 3, the value of the non-originating goods in the set and the value of the set shall be calculated in the same manner as the value of non-originating materials and the value of the good.

{{ Article 16 }}