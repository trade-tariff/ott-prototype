1.	If goods are classified as a set, in accordance with the General Rules for the Interpretation of the Harmonized System, the set is originating only if:

    (a)	each good in the set is originating; or 

    (b)	the set contains a non-originating component good; and 

    - (i)	at least one of the component goods of the set is originating; and 

    - (ii)	the value of all of the set’s non-originating component goods does not exceed 20 per cent of the value of the set. 

2.	For the purposes of paragraph 1, the value of the set shall be calculated in the same manner as the value of the good and the value of the set’s non-originating component goods shall be calculated in the same manner as the value of non-originating materials.

{{ Article 13 }}