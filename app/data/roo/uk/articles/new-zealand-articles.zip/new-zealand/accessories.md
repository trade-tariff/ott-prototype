1. For the purpose of determining origin of a good, accessories, spare parts, tools, and instructional or other information materials classified and delivered with, but not invoiced separately from a good shall be:

   1. disregarded in determining whether a good is wholly obtained or satisfies a process or change in tariff classification requirement set out in Annex II (Product-Specific Rules) for the good; and

   2. taken into account as originating or non-originating materials, as the case may be, in calculating the regional value content of the good, 

   provided the quantities, value, and type of accessories, spare parts, tools, and instructional or other information material are customary for the good.

2. Accessories, spare parts, tools, and instructional or other information materials, described in paragraph 1 shall be deemed to have the same originating status as the good with which they are delivered.

{{ Article 12 }}
