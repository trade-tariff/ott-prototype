Accessories, spare parts and tools dispatched with a piece of equipment, machine, apparatus or vehicle, which are part of the normal equipment and included in the price thereof or which are not separately invoiced, shall be regarded as one with the piece of equipment, machine, apparatus or vehicle in question.

{{ Article 11 }}
