For the purpose of implementing the Agreement, the following products shall be considered as originating in a SACU Member State or Mozambique, as the case may be:

- products **wholly obtained** in that SACU Member State or Mozambique;

- products obtained in a SACU Member State or Mozambique incorporating materials which have not been wholly obtained there, provided that such materials have undergone **sufficient working or processing** in that SACU Member State or Mozambique respectively.
