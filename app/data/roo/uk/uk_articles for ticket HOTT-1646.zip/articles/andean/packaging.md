Where, under paragraph 5 of Part Two, Section 1, of the Tariff of the United Kingdom, packaging is included with the product for classification purposes, such packaging shall be included for the purposes of determining origin.

When the products qualify as wholly obtained, the packaging shall not be taken into consideration for the purposes of determining origin

{{ Article 8 }}
