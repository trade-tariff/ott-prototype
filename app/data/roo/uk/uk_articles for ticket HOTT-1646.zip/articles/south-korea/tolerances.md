There is no tolerance information in the South Korea document.
