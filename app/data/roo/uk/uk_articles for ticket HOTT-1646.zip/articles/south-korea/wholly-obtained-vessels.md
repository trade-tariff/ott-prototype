The terms "its vessels" and "its factory ships" in paragraph 1(f) and (g) shall apply only to vessels and factory ships:

1. which are registered in the UK or Korea; 

2. which sail under the flag of the UK or Korea; and 

3. which meet one of the following conditions: 

   1. they are at least 50 percent owned by nationals of the UK or Korea; or 

   2. they are owned by companies: 

      1. which have their head office and their main place of business in the UK or in Korea; and 

      2. which are at least 50 percent owned by the UK or by Korea, public entities of the UK or Korea, or nationals of the UK or Korea. 
