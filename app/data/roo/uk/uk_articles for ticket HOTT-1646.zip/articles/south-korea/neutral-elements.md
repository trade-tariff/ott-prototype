### Neutral elements

In order to determine whether a product originates, it shall not be necessary to determine the origin of the goods which might be used in its manufacture, but which do not enter and which are not intended to enter into the final composition of the product.

{{ Article 10 }}
