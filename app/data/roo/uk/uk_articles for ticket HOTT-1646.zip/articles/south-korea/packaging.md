Where, under paragraph 5 of the Part Two, Section 1, of the Tariff of the United Kingdom, packaging is included with the product for classification purposes, it shall be included for the purposes of determining origin, and considered as originating if the product is originating.

{{ Article 7 }}
