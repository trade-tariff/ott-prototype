Accessories, spare parts and tools delivered with a product, which are part of the normal equipment and included in the price thereof or which are not separately invoiced, shall be regarded as one with the product in question.

{{ Article 8 }}
