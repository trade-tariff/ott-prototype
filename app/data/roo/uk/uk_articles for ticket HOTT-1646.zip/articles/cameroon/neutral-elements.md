
In order to determine whether a product is an originating product, it shall not be necessary to determine the origin of the following which might be used in its manufacture:

- energy and fuel;

- plant and equipment;

- machines and tools;

- goods which do not enter and which are not intended to enter into the final composition of the product.

{{ Article 10 }}
