For the purposes of the United Kingdom-Cameroon Agreement, the following products shall be considered as originating in Cameroon:

- products **wholly obtained** in Cameroon *or*

- products obtained in Cameroon incorporating materials which have not been wholly obtained there, provided that such materials have undergone **sufficient working or processing** in Cameroon.
