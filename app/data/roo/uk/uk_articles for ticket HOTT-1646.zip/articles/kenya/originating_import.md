For the purpose of the United Kingdom-EAC Agreement, the following products shall be considered as originating in an EAC Partner State:

- products **wholly obtained** in an EAC Partner State;

- products obtained in an EAC Partner State incorporating materials which have not been wholly obtained there, provided that such materials have undergone **sufficient working or processing** in that EAC Partner State.
