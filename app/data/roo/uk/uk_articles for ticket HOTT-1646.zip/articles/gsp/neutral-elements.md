1. In determining the origin of goods, neutral elements used to process, or used in the course of processing, the goods are to be disregarded.

2. In this regulation, "neutral elements" means:

   1. energy in the form of fuel, or in any other form;

   2. plant or equipment, including machinery and tools;

   3. materials which do not form part of, or are not integral to, the final composition of the goods.
