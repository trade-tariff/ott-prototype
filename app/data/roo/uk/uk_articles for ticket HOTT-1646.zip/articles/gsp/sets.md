Goods in a set for retail sale are to be regarded as goods originating from a beneficiary country if:

- all the components are originating materials, or
- where the set is composed of a mixture of originating materials and non-originating materials, the value of the non-originating materials does not exceed 15% of the ex-works price of the set.