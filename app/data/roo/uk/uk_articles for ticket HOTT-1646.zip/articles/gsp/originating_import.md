Qualifying goods listed in Column 2 of the table in Part 2 of Schedule 1 are to be regarded as originating from a beneficiary country if:

1. the goods are **wholly obtained** in that beneficiary country in accordance with regulation 6;

2. where the goods are obtained in **two or more countries or territories**, that beneficiary country is the last country or territory in which processing of the goods which constitutes an important stage of manufacture has taken place in accordance with regulation 7;

3. the requirements set out in regulation 20(1) are met;

4. in the case of returned goods, the requirements set out in regulation 19 are met; and

5. the evidence requirements set out in regulation 4 are met.