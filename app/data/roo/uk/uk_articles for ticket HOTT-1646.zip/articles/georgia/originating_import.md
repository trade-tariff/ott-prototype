
For the purpose of implementing the United Kingdom-Georgia Agreement, the following products shall be considered as originating in Georgia:

- products **wholly obtained** in Georgia within the meaning of Article 5 of this Origin Reference Document;

- products obtained in Georgia incorporating materials which have not been wholly obtained there, provided that such materials have undergone **sufficient working or processing** in Georgia.
