

In order to determine whether a product is an originating product, it shall not be necessary to determine the origin of the following which might be used in its manufacture:

a) energy and fuel;

b) plant and equipment;

c) machines and tools;

d) goods which neither enter into the final composition of the product nor are intended to do so.

{{ Article 11 }}
