For the purpose of implementing the **United Kingdom-Ukraine Agreement**, the following products are considered as originating in Ukraine:

- products **wholly obtained** in Ukraine *and* 

- products obtained in Ukraine incorporating materials which have not been wholly obtained there, provided that such materials have undergone **sufficient working or processing in Ukraine**.
