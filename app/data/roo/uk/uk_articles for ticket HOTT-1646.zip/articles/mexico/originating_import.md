For the purpose of implementing the United Kingdom-Mexico Agreement, the following products shall be considered as originating in Mexico:

- products **wholly obtained** in Mexico;

- products obtained in Mexico incorporating materials which have not been wholly obtained there, provided that such materials have undergone **sufficient working or processing** in Mexico.

Products manufactured exclusively from materials which comply with the provisions set out in Articles 4 or 5 shall also be considered as originating in Mexico or the United Kingdom.
