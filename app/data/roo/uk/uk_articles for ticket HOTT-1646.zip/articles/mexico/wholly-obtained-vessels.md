The terms 'their vessels' and 'their factory ships' in paragraph 1(f) and (g) shall apply only to vessels and factory ships:

1. which are registered or recorded in Mexico or in the United Kingdom;

2. which sail under the flag of Mexico or the United Kingdom;

3. which are owned to an extent of at least 50 % by nationals of the United Kingdom, Member States of the European Union or Mexico, or by a company with its head office in the United Kingdom, one of the Member States of the European Union or Mexico, of which the manager or managers, chairman of the board of directors or the supervisory board, and the majority of the members of such boards are nationals of the United Kingdom, Member States of the European Union or Mexico and of which, in addition, in the case of partnerships or limited companies, at least half the capital belongs to the United Kingdom, one of the Member States of the European Union or Mexico or to public bodies or nationals( ) of the United Kingdom, Member States of the European Union or Mexico;

4. of which the master and officers are nationals of the United Kingdom, Member States of the European Union or Mexico;  

5. of which at least 75 % of the crew are nationals of the United Kingdom, Member States of the European Union or Mexico.

{{ Article 4 }}