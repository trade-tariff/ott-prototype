For the purpose of implementing the United Kingdom-Switzerland Agreement, the following products shall be considered as originating in a Party:

- products **wholly obtained** in a Party;

- products obtained in a Party incorporating materials which have not been wholly obtained there, provided that such materials have undergone **sufficient working or processing** in that Party.
