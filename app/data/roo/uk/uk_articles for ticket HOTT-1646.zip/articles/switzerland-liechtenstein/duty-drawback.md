## Drawback of or exemption from customs duties

1.	Non-originating materials used in the manufacture of products falling within Chapters 50 to 63 of HS 2017 originating in a Party for which a proof of origin is issued or made out in accordance with Title V of this Origin Reference Document shall not be subject in the exporting Party to drawback of or exemption from customs duties of whatever kind.

2.	The prohibition in paragraph 1 shall apply to any arrangement for refund, remission or non-payment, partial or complete, of customs duties or charges having an equivalent effect, applicable in the exporting Party to materials used in the manufacture, where such refund, remission or non-payment applies, expressly or in effect, when products obtained from the said materials are exported and not when they are retained for home use there.

3.	The exporter of products covered by a proof of origin shall be prepared to submit at any time, upon request from the customs authorities, all appropriate documents proving that no drawback has been obtained in respect of the non-originating materials used in the manufacture of the products concerned and that all customs duties or charges having equivalent effect applicable to such materials have actually been paid.

4.	The prohibition in paragraph 1 shall not apply to trade between the Parties for products that obtained originating status by application of cumulation of origin covered by Article 7(4) or (5).
