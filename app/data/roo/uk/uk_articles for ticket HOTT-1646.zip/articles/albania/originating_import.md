For the purpose of implementing the **United Kingdom-Albania Agreement**, the following products shall be considered as originating in Albania:
- products **wholly obtained** in Albania *or*
- products obtained in Albania incorporating materials which have not been wholly obtained there, provided that such materials have undergone **sufficient working or processing in Albania**
