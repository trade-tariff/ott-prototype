For the purpose of implementing Title II (Trade in Goods) of Part IV of the Agreement, the following products shall be considered as originating in Central America:

- products **wholly obtained** in Central America;

- products obtained in Central America incorporating materials which have not been wholly obtained there, provided that such materials have undergone **sufficient working or processing** in Central America.
