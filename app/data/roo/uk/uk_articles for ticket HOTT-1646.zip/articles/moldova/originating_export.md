For the purpose of implementing the United Kingdom-Moldova Agreement, the following products shall be considered as originating in the UK:

- products **wholly obtained** in the UK;
- 
- products obtained in the UK incorporating materials which have not been wholly obtained there, provided that such materials have undergone **sufficient working or processing** in the UK.
