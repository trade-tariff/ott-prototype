
For the purpose of implementing the United Kingdom-Moldova Agreement, the following products shall be considered as originating in the Republic of Moldova:

- products **wholly obtained** in the Republic of Moldova;

- products obtained in the Republic of Moldova incorporating materials which have not been wholly obtained there, provided that such materials have undergone **sufficient working or processing** in the Republic of Moldova.
