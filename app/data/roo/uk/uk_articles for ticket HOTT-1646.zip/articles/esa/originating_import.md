For the purpose of the Agreement, the following products shall be considered as originating in an ESA State:

- products **wholly obtained** in an ESA State;

- products obtained in an ESA State incorporating materials which have not been wholly obtained there, provided that such materials have undergone **sufficient working or processing** in that ESA State.

