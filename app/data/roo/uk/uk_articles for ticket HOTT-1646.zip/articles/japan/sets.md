A set, classified pursuant to paragraphs 3(b) and (c) of Part Two, Section 1, of the Tariff of the United Kingdom, shall be considered as originating in a Party when all of its components are originating under this Origin Reference Document.

Where the set is composed of originating and non-originating components, it shall as a whole be considered as originating in a Party, provided that the value of the non-originating components does not exceed 15 per cent of the ex-works or free on board price of the set.

{{ Article 9 }}