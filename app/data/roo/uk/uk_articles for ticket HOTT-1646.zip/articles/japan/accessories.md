1. For the purposes of this Article, accessories, spare parts, tools and instructional or other information materials are covered if:

   1. the accessories, spare parts, tools and instructional or other information materials are classified and delivered with, but not invoiced separately from, the product; and

   2. the types, quantities and value of the accessories, spare parts, tools and instructional or other information materials are customary for that product.

2. In determining whether a product is wholly obtained, or satisfies a production process or change in tariff classification requirement as set out in Annex B, accessories, spare parts, tools and instructional or other information materials shall be disregarded.

3. In determining whether a product meets a value requirement set out in Annex B, the value of accessories, spare parts, tools and instructional or other information materials shall be taken into account as originating or non-originating materials, as the case may be, in the calculation for the purpose of the application of the value requirement to the product.

4. A product's accessories, spare parts, tools and instructional or other information materials shall have the originating status of the product with which they are delivered.

{{ Article 12 }}
