For the purpose of implementing the United Kingdom-Morocco Agreement, the following products shall be considered as originating in Morocco:

- products **wholly obtained** in Morocco;

- products obtained in Morocco incorporating materials which have not been wholly obtained there, provided that such materials have undergone **sufficient working or processing** in Morocco.
