For the purposes of this the United Kingdom-Ghana Agreement the following products shall be considered as originating in Ghana:

- products **wholly obtained** in Ghana;

- products obtained in Ghana incorporating materials which have not been wholly obtained there, provided that such materials have undergone **sufficient working or processing** in Ghana.
