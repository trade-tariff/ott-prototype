Where, under paragraph 5 of Part Two, Section 1, of the Tariff of the United Kingdom, packaging is included in the product for classification purposes, it shall be included for the purposes of determining origin.

{{ Article 7 }}
