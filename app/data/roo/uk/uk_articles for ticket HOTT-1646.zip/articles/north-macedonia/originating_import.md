For the purpose of implementing the United Kingdom-North Macedonia Agreement, the following products shall be considered as originating in North Macedonia:

- products **wholly obtained** in North Macedonia;

- products obtained in North Macedonia incorporating materials which have not been wholly obtained there, provided that such materials have undergone **sufficient working or processing** in North Macedonia.
