For the purposes of the United Kingdom-Côte d'Ivoire Agreement, the following products shall be considered as originating in Côte d'Ivoire:

- products **wholly obtained** in Côte d'Ivoire;

- products obtained in Côte d'Ivoire incorporating materials which have not been wholly obtained there, provided that such materials have undergone **sufficient working or processing** in Côte d'Ivoire.
