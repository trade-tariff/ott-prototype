For the purposes of the United Kingdom-Côte d'Ivoire Agreement, the following products shall be considered as originating in the United Kingdom:

- products **wholly obtained** in the United Kingdom;
- products obtained in the United Kingdom incorporating materials which have not been wholly obtained there, provided that such materials have undergone **sufficient working or processing** in the United Kingdom.
