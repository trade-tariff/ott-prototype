In order to determine whether a product is an originating product, no account will be taken of the origin of the following which might be used in its manufacture:

- energy and fuel;

- plant and equipment;

- machines and tools;

- any other goods which do not enter, and which are not intended to enter, into the final composition of the product.
