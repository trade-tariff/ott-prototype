1. The following products will be considered as originating in an Overseas Territory:

   1. products **wholly obtained** in an Overseas Territory within the meaning of paragraph 3 of this Annex;

   2. products obtained in an Overseas Territory incorporating materials which have not been wholly obtained there, provided that such materials have undergone **sufficient working or processing** within the meaning of paragraph 4 of this Annex.

2. Originating products made up of materials wholly obtained or sufficiently worked or processed in two or more Overseas Territories will be considered to be products originating in the Overseas Territory where the last working or processing took place.
