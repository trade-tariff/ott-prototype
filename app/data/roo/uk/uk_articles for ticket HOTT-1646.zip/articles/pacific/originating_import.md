For the purpose of the United Kingdom – Pacific States Agreement, the following products shall be considered as originating in a Pacific State:

- products **wholly obtained** in a Pacific State;

- products obtained in a Pacific State incorporating materials which have not been wholly obtained there, provided that such materials have undergone **sufficient working or processing** in that Pacific State.
