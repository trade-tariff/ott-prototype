For the purpose of implementing the United Kingdom-Kosovo Agreement, the following products shall be considered as originating in Kosovo:

- products **wholly obtained** in Kosovo; *and* 

- products obtained in Kosovo incorporating materials which have not been wholly obtained there, provided that such materials have undergone **sufficient working or processing** in Kosovo.
