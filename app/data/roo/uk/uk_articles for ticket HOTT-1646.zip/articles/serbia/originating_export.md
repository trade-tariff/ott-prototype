For the purpose of implementing the United Kingdom-Serbia Agreement, the following products shall be considered as originating in Serbia:

- products **wholly obtained** in Serbia;

- products obtained in Serbia incorporating materials which have not been wholly obtained there, provided that such materials have undergone **sufficient working or processing** in Serbia.
