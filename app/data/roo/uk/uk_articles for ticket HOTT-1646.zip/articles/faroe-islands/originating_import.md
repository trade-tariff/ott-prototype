For the purpose of implementing the United Kingdom-Faroe Islands Agreement, the following products shall be considered as originating in the Faroe Islands:

- products **wholly obtained** in the Faroe Islands;

- products obtained in the Faroe Islands incorporating materials which have not been wholly obtained there, provided that such materials have undergone **sufficient working or processing** in the Faroe Islands.
