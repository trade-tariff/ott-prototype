For the purpose of implementing the Agreement, the following products shall be considered as originating in Tunisia:

- products **wholly obtained** in Tunisia;

- products obtained in Tunisia incorporating materials which have not been wholly obtained there, provided that such materials have undergone **sufficient working or processing** in Tunisia.
