### Sets

Sets, as defined in paragraph 3 of the Tariff of the United Kingdom, shall be regarded as originating when all component products are originating. Nevertheless, when a set is composed of originating and non-originating products, the set as a whole shall be regarded as originating, provided that the value of the non-originating products does not exceed 15 % of the ex-works price of the set.

{{ Article 9 }}
