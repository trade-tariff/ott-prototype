1. Accessories, spare parts, tools and instructional or other information materials shall be regarded as one product with the piece of equipment, machine, apparatus or vehicle in question if they:

   1. are classified and delivered with, but not invoiced separately from, the product; *and*

   2. are of the types, quantities and value which are customary for that product.

2. Accessories, spare parts, tools and instructional or other information materials referred to in paragraph 1 shall be disregarded in determining the origin of the product except for the purposes of calculating the value of non-originating materials if a product is subject to a maximum value of non-originating materials as set out in the Trade and Cooperation Agreement.

{{ Article 11 }}
