### Sets

Sets, as defined in paragraph 3 of Part Two, Section 1, of the Tariff of the United Kingdom, shall be considered as originating in a Party if all of their components are originating. If a set is composed of originating and non-originating components, the set as a whole shall be considered as originating in a Party, if the value of the non-originating components does not exceed 15 % of the ex-works price of the set.

{{ Article 11}}
